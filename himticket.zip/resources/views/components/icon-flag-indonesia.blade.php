<svg id="indonesia-flag" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 20" width="20" height="20">
    <rect width="30" height="20" fill="#fff" />
    <rect width="30" height="10" fill="#ce1126" />
</svg>
